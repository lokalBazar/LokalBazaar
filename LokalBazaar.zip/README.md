# Lokal Bazaar

A full-stack shopping website with React frontend and Node.js backend.